const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

app.post('/completion', async (req, res) => {
  try {
    const { prompt } = req.body;
    const response = await axios.post('http://localhost:11434/api/generate', {
      model: "mistral",
      prompt,
      stream: false
    });
    res.json({ response: response.data.response });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur proxy' });
  }
});

app.listen(11556, () => {
  console.log('✅ Proxy prêt sur http://localhost:11556');
});
