#!/data/data/com.termux/files/usr/bin/bash

echo "📦 Installation de BouleMini v17..."

# Définir les chemins
ZIP_NAME="BouleMini_v17.zip"
DEST_DIR="$HOME/BouleMini"
DOWNLOAD_PATH="$HOME/storage/downloads/$ZIP_NAME"
ZIP_PATH="$HOME/$ZIP_NAME"

# Étape 1 : Copier depuis Téléchargements
if [ -f "$DOWNLOAD_PATH" ]; then
    echo "📁 Copie de l’archive depuis les téléchargements..."
    cp "$DOWNLOAD_PATH" "$ZIP_PATH"
else
    echo "❌ Archive non trouvée dans les téléchargements : $DOWNLOAD_PATH"
    exit 1
fi

# Étape 2 : Décompression
echo "🗜️ Décompression dans $DEST_DIR..."
mkdir -p "$DEST_DIR"
unzip -o "$ZIP_PATH" -d "$DEST_DIR"

# Étape 3 : Rendre exécutable le script principal
chmod +x "$DEST_DIR/start.sh"

# Étape 4 : Lancer BouleMini
echo "🚀 Lancement de BouleMini..."
"$DEST_DIR/start.sh"

echo "✅ Installation terminée."
