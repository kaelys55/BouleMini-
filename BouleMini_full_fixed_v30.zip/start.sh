#!/bin/bash
echo "🚀 Lancement de Boule Mini..."
mkdir -p ~/BouleMini/logs

# Démarrage Ollama si non lancé
if ! pgrep -x ollama > /dev/null; then
  echo "🔁 Démarrage d'Ollama..."
  nohup ollama serve > ~/BouleMini/logs/ollama.log 2>&1 &
  sleep 2
else
  echo "✅ Ollama déjà lancé"
fi

# Lancer le proxy Express sur port 11556
echo "▶️  Lancement du proxy Express vers Ollama..."
cd ~/BouleMini/ollama-proxy || exit
nohup node index.js > ~/BouleMini/logs/proxy.log 2>&1 &

# Lancer le frontend sur port 45563
echo "🖥️ Lancement du frontend web sur http://localhost:45563..."
cd ~/BouleMini/frontend || exit
nohup python3 -m http.server 45563 > ~/BouleMini/logs/frontend.log 2>&1 &

echo "✅ Accès local : http://localhost:45563"
