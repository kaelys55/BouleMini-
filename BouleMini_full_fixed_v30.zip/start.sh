#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 Lancement de Boule Mini..."

# Lancer Ollama si non déjà actif
pgrep -x ollama > /dev/null || (echo "🔁 Démarrage d'Ollama..."; nohup ollama serve > /dev/null 2>&1 & sleep 2)

# Lancer le proxy
echo "▶️  Lancement du proxy Express vers Ollama..."
cd "$(dirname "$0")/ollama-proxy"
nohup node index.js > ../logs/proxy.log 2>&1 &

# Lancer le frontend
echo "🖥️ Lancement du frontend web sur http://localhost:45563..."
cd ../frontend
nohup python3 -m http.server 45563 > ../logs/frontend.log 2>&1 &

echo "✅ Accès local : http://localhost:45563"
